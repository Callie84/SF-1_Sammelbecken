🤖 Telegram-Bot Integration:
- Verzeichnis: SF1/bot
- Dateien:
  • config.js: Bot-Token & Prefix
  • index.js: Einstiegspunkt, Command-Dispatcher
  • commands/help.js: Hilfe-Text
  • commands/search.js: /search <query> → SF-1 API /seeds?search=
  • commands/wishlist.js: /wishlist add|list → Wishlist-API
- Setup:
  • Umgebungsvariablen: TELEGRAM_BOT_TOKEN, API_URL, API_TOKEN
  • Installation: npm install node-telegram-bot-api node-fetch
  • Start: node bot/index.js