fetch('../src/data/UGG1-Auszug.html')
  .then(res => res.text())
  .then(html => {
    document.getElementById('uggContent').innerHTML = html;
  })
  .catch(err => {
    document.getElementById('uggContent').textContent = 'Fehler beim Laden von UGG-1.';
    console.error(err);
  });