module.exports = {
  token: process.env.TELEGRAM_BOT_TOKEN,
  prefix: '/'
};