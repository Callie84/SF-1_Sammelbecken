🔍 Seed-Vergleich (Modul 24):
- POST /compare
- Body: { strains: ["Sorte A", "Sorte B", "Sorte C"] }
- Antwort: Sorten-Daten nebeneinander zur direkten Analyse