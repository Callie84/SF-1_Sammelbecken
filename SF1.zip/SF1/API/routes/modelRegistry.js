const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { getModels, removeModel } = require('../controllers/modelController');

// Modelle auflisten (Admin)
router.get('/', auth, role(['admin']), getModels);

// Modell löschen (Admin)
router.delete('/:name', auth, role(['admin']), removeModel);

module.exports = router;