// Übersicht aller Routen zum Import
module.exports = {
  search: require('./search'),
  auth: require('./auth'),
  profile: require('./profile'),
  wishlist: require('./wishlist'),
  shops: require('./shops'),
  reviews: require('./reviews'),
  // ...
};