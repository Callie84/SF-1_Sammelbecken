const express = require('express');
const router = express.Router();
const { autocomplete } = require('../controllers/autocompleteController');

// GET /api/seeds/autocomplete?q=<query>&limit=<number>
router.get('/autocomplete', autocomplete);

module.exports = router;