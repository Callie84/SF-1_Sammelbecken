const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { stageDistribution, downloadExcel } = require('../controllers/chartController');

// Chart-Daten: Stage-Verteilung
router.get('/growcycles/:id/stages', auth, stageDistribution);

// Excel-Export aller Zyklen
router.get('/growcycles/export/excel', auth, downloadExcel);

module.exports = router;