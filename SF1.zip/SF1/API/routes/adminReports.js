const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { planStats, userStats, usageStats } = require('../controllers/adminReportController');

router.use(auth, role(['admin']));

router.get('/plans', planStats);
router.get('/users', userStats);
router.get('/usage', usageStats);

module.exports = router;