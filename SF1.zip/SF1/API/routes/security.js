const express = require('express');
const router = express.Router();
const { refreshToken } = require('../controllers/tokenController');
const rateLimit = require('../middleware/rateLimit');

// Refresh Access Token
router.post('/refresh-token', rateLimit, refreshToken);

module.exports = router;