const express = require('express');
const router = express.Router();
const { listSeedbanks } = require('../controllers/seedbankDBController');

// GET /api/seedbanks
router.get('/', listSeedbanks);

module.exports = router;