const express = require("express");
const router = express.Router();
const multer = require("multer");
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");
const { bulkImport } = require("../controllers/seedbankImportController");

// Multer Setup
const upload = multer({ dest: 'uploads/' });

router.post("/bulk", auth, role(["admin"]), upload.single("file"), bulkImport);

module.exports = router;