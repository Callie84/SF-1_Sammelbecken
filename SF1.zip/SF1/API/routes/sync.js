const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const controller = require("../controllers/syncController");

router.use(auth);

// Sync abrufen
router.get("/sync", controller.getSyncData);

// Sync senden
router.post("/sync", express.json(), controller.postSyncData);

module.exports = router;