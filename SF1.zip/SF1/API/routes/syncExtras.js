const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const { registerDevice, listDevices } = require("../controllers/deviceController");
const { backgroundSync } = require("../services/syncService");

// Geräteverwaltung
router.post("/devices", auth, express.json(), registerDevice);
router.get("/devices", auth, listDevices);

// Background-Sync manuell triggern (optional)
router.post("/sync/background", auth, express.json(), async (req, res) => {
  const resolved = await backgroundSync(req.user.id, req.body.changes);
  res.json({ resolved });
});

module.exports = router;