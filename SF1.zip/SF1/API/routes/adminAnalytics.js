const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { channelStats, messageStats, eventStats } = require('../controllers/adminAnalyticsController');

router.use(auth, role(['admin']));

router.get('/channels', channelStats);
router.get('/messages', messageStats);
router.get('/events', eventStats);

module.exports = router;