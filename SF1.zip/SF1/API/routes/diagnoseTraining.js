const express = require('express');
const multer = require('multer');
const auth = require('../middleware/authMiddleware');
const { train } = require('../controllers/trainingController');
const { predict } = require('../controllers/inferenceController');

const router = express.Router();

// Training anstossen (Admin)
router.post('/train', auth, train);

// Inferenz: Bild hochladen und vorhersagen
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/diagnose/'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
});
const upload = multer({ storage });

router.post('/predict', auth, upload.single('image'), predict);

module.exports = router;