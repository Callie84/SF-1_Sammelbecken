const express = require("express");
const router = express.Router();
const path = require("path");

// Beispiel: HTML-Datei bereitstellen
router.get("/html/:file", (req, res) => {
  const file = req.params.file;
  const filePath = path.join(__dirname, "../../public/downloads/html", file);
  res.download(filePath);
});

// Beispiel: PDF-Datei bereitstellen
router.get("/pdf/:file", (req, res) => {
  const file = req.params.file;
  const filePath = path.join(__dirname, "../../public/downloads/pdf", file);
  res.download(filePath);
});

// Beispiel: CSV-Datei bereitstellen
router.get("/csv/:file", (req, res) => {
  const file = req.params.file;
  const filePath = path.join(__dirname, "../../public/downloads/csv", file);
  res.download(filePath);
});

module.exports = router;