const express = require('express');
const router = express.Router();
const { detail } = require('../controllers/detailController');

// GET /api/seeds/:strain
router.get('/:strain', detail);

module.exports = router;