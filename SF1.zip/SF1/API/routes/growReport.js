const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { timeline, downloadCSV, summary } = require('../controllers/growReportController');

router.use(auth);

// Zeitachse eines GrowCycle
router.get('/growcycles/:id/timeline', timeline);

// CSV-Export für Cycle
router.get('/growcycles/:id/export', downloadCSV);

// Zusammenfassung aller Zyklen
router.get('/growcycles/summary', summary);

module.exports = router;