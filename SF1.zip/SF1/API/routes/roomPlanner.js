const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const ctl = require('../controllers/roomPlannerController');

router.use(auth);

router.post('/layout', ctl.saveLayout);
router.get('/layouts', ctl.getLayouts);
router.post('/layout/:id/prices', ctl.getPrices);

module.exports = router;