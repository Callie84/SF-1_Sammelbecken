const express = require('express');
const router = express.Router();
const { filterOptions } = require('../controllers/optionsController');

// GET /api/seeds/options
router.get('/options', filterOptions);

module.exports = router;