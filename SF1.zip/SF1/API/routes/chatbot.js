const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { chat } = require('../controllers/chatbotController');

router.use(auth);
router.post('/message', express.json(), chat);

module.exports = router;