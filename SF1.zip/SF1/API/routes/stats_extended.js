const express = require("express");
const router = express.Router();
const Statistik = require("../models/Statistik");

// Top-Strains nach Klicks
router.get("/top-clicks", async (req, res) => {
  const top = await Statistik.find().sort({ clicks: -1 }).limit(10);
  res.json(top);
});

// Top-Strains nach Suchhäufigkeit
router.get("/top-searches", async (req, res) => {
  const top = await Statistik.find().sort({ searches: -1 }).limit(10);
  res.json(top);
});

// Zeige alle Statistiken sortiert nach Update-Datum
router.get("/all", async (req, res) => {
  const all = await Statistik.find().sort({ updatedAt: -1 });
  res.json(all);
});