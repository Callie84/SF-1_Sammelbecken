const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const ctl = require('../controllers/growcycleController');

router.use(auth);

router.post('/', ctl.createCycle);
router.get('/', ctl.getCycles);
router.get('/:id', ctl.getCycle);
router.delete('/:id', ctl.deleteCycle);

module.exports = router;