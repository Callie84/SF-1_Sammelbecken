const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { processReminders } = require('../services/reminderService');

// Manuelle Auslösung
router.use(auth);
router.post('/reminders/process', async (req, res) => {
  await processReminders();
  res.json({ message: 'Reminder-Check abgeschlossen' });
});

module.exports = router;