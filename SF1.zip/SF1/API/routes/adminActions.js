const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");
const {
  updateUserRole,
  deleteUser,
  triggerRescrape,
  clearLogs
} = require("../controllers/adminActionController");

// Admin-only
router.use(auth, role(["admin"]));

// Nutzerbearbeitung
router.put("/users/:id/role", updateUserRole);
router.delete("/users/:id", deleteUser);

// Aktionen
router.post("/actions/rescrape", triggerRescrape);
router.delete("/actions/logs", clearLogs);

module.exports = router;