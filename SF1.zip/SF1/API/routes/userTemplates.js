const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const ctl = require('../controllers/userTemplateController');

router.use(auth);

router.post('/user/templates', express.json(), ctl.saveTemplate);
router.get('/user/templates', ctl.getTemplates);
router.delete('/user/templates/:id', ctl.removeTemplate);

module.exports = router;