const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { enableMfa, verifyMfa } = require('../controllers/mfaController');

// POST /security/mfa/enable
router.post('/mfa/enable', auth, enableMfa);

// POST /security/mfa/verify
router.post('/mfa/verify', auth, verifyMfa);

module.exports = router;