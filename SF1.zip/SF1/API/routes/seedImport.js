const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { runImport } = require('../controllers/seedImportController');

// Admin-only import trigger
router.post('/seeds/import', auth, role(['admin']), runImport);

module.exports = router;