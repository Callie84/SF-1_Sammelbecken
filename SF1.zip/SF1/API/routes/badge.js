const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const ctl = require('../controllers/badgeController');

router.use(auth);

router.post('/badges', role(['admin']), ctl.createBadge);
router.post('/badges/award', role(['admin']), ctl.awardBadge);
router.get('/users/:userId/badges', ctl.listUserBadges);

module.exports = router;