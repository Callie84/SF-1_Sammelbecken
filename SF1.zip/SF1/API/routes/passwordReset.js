const express = require('express');
const router = express.Router();
router.post('/password-reset', express.json(), require('../controllers/passwordResetController').requestReset);
router.post('/password-reset/:token', express.json(), require('../controllers/passwordResetController').resetPassword);
module.exports = router;