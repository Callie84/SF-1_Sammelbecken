const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { overall, cycle } = require('../controllers/growAnalyticsController');

// Gesamte Nutzerdaten
router.get('/growcycles/analytics', auth, overall);
// Einzelner Zyklus
router.get('/growcycles/:id/analytics', auth, cycle);

module.exports = router;