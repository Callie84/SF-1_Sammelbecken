const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { powerHistory, yieldHistory } = require('../controllers/historyController');

router.use(auth);

router.get('/power', powerHistory);
router.get('/yield/:cycleId', yieldHistory);

module.exports = router;