const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const ctl = require('../controllers/setupController');

router.use(auth);

// Einkaufsliste
router.post('/items', ctl.createItem);
router.get('/items', ctl.listItems);

// Budget-Planer
router.get('/budget', ctl.getBudget);

// Markieren
router.put('/items/:id/purchase', ctl.markPurchased);

module.exports = router;