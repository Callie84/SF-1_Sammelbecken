const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { subscribePush, unsubscribePush, triggerAlerts } = require('../controllers/notificationController');

router.use(auth);

// POST /notifications/subscribe
router.post('/subscribe', subscribePush);

// POST /notifications/unsubscribe
router.post('/unsubscribe', unsubscribePush);

// POST /notifications/trigger
router.post('/trigger', triggerAlerts);

module.exports = router;