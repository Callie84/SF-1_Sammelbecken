const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { forecast, exportForecast } = require('../controllers/forecastController');

// JSON-Körper parsen
router.use(express.json());
router.use(auth);

// Prognose automatisch
router.post('/forecast', forecast);

// CSV-Export
router.post('/forecast/export', exportForecast);

module.exports = router;