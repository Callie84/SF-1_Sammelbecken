const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const ctl = require('../controllers/groupEventController');

router.use(auth);

router.post('/', ctl.createGE);
router.get('/', ctl.listGE);
router.post('/:id/join', ctl.joinGE);
router.post('/:id/rsvp', ctl.rsvpEvent);

module.exports = router;