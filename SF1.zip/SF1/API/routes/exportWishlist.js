const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { exportWishlistCSV } = require('../controllers/wishlistExportController');

// GET /wishlist/export/:id
router.get('/export/:id', auth, exportWishlistCSV);

module.exports = router;