const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { runPriceUpdate } = require('../controllers/priceUpdateController');

// Admin only route
router.post('/seeds/update-prices', auth, role(['admin']), runPriceUpdate);

module.exports = router;