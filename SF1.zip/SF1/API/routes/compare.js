const express = require("express");
const router = express.Router();
const Seed = require("../models/Seed"); // Modell muss existieren

// Vergleicht 2 oder 3 Sorten anhand ihrer Attribute
router.post("/", async (req, res) => {
  const { strains } = req.body; // erwartet Array mit 2–3 Strain-Namen
  if (!Array.isArray(strains) || strains.length < 2 || strains.length > 3)
    return res.status(400).json({ error: "2–3 Sorten erforderlich" });

  const result = await Seed.find({ strain: { $in: strains } });
  res.json(result);
});

module.exports = router;