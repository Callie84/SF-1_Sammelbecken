const express = require('express');
const router = express.Router();
const multer = require('multer');
const auth = require('../middleware/authMiddleware');
const UploadedSeed = require('../models/UploadedSeed');

// Multer Setup für Bild-Upload
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/seeds/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// Sorten-Upload (JSON + Bild optional)
router.post('/', auth, upload.single('image'), async (req, res) => {
  const { strain, genetics, thc, cbd, description } = req.body;
  const imageUrl = req.file ? `/uploads/seeds/${req.file.filename}` : '';
  const seed = new UploadedSeed({ userId: req.user.id, strain, genetics, thc, cbd, description, imageUrl });
  await seed.save();
  res.status(201).json(seed);
});

// Eigene Uploads abrufen
router.get('/', auth, async (req, res) => {
  const seeds = await UploadedSeed.find({ userId: req.user.id });
  res.json(seeds);
});

module.exports = router;