const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { searchProducts, addCart } = require('../controllers/partnerController');

router.use(auth);

// Partner-API-Stubs
router.get('/partner/search', searchProducts);
router.post('/partner/cart', express.json(), addCart);

module.exports = router;