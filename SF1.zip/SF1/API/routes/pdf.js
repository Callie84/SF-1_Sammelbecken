const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { downloadPDF } = require('../controllers/pdfController');

// PDF-Export für GrowCycle
router.get('/growcycles/:id/pdf', auth, downloadPDF);

module.exports = router;