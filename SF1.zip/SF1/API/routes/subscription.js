const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { startSubscription, webhook, getSubscription } = require('../controllers/subscriptionController');

router.post('/subscription/start', auth, express.json(), startSubscription);
router.post('/subscription/webhook', express.json(), webhook);
router.get('/subscription', auth, getSubscription);

module.exports = router;