const express = require('express');
const router = express.Router();
const { createShare, getShare } = require('../controllers/wishlistShareController');

router.post('/share/:id', createShare);
router.get('/share/:token', getShare);

module.exports = router;