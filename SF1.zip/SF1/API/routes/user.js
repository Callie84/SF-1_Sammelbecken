const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");
const User = require("../models/User");

// Benutzerprofil abrufen
router.get("/me", auth, async (req, res) => {
  const user = await User.findById(req.user.id).select("-password");
  res.json(user);
});

// Benutzerprofil ändern
router.put("/me", auth, async (req, res) => {
  const update = { username: req.body.username, email: req.body.email };
  const user = await User.findByIdAndUpdate(req.user.id, update, { new: true }).select("-password");
  res.json(user);
});

// Admin-only: Liste aller Benutzer
router.get("/all", auth, role(["admin"]), async (req, res) => {
  const users = await User.find().select("username email role");
  res.json(users);
});

module.exports = router;