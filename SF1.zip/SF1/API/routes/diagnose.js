const express = require('express');
const router = express.Router();
const multer = require('multer');
const auth = require('../middleware/authMiddleware');
const { uploadAndDiagnose, listDiagnoses } = require('../controllers/diagnoseController');

// Setup Multer
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/diagnose/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// Auth nötig
router.use(auth);

// POST /diagnose/upload → Bild hochladen + Diagnose
router.post('/upload', upload.single('image'), uploadAndDiagnose);

// GET /diagnose → eigene Diagnosen abrufen
router.get('/', listDiagnoses);

module.exports = router;