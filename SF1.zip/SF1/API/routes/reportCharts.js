const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { dailyRegistrations, exportPlansExcel } = require('../controllers/reportChartController');

// Auth + Admin
router.use(auth, role(['admin']));

// Zeitreihen-API
router.get('/registrations', dailyRegistrations);

// Excel-Export Plan-Stats
router.get('/export/plans', exportPlansExcel);

module.exports = router;