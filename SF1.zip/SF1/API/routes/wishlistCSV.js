const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const role = require('../middleware/roleMiddleware');
const { importCSV, exportCSV } = require('../controllers/wishlistCSVController');

// Bulk Import from CSV (Admin)
router.post('/wishlist/import', auth, role(['admin']), importCSV);

// Export Wishlist to CSV (User)
router.get('/wishlist/export', auth, exportCSV);

module.exports = router;