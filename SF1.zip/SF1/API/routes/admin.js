const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");
const controller = require("../controllers/adminController");

// Admin-only
router.use(auth, role(["admin"]));

router.get("/users", controller.listUsers);
router.get("/logs", controller.listLogs);
router.get("/seedbanks", controller.listSeedbanks);
router.get("/alerts", controller.listAlerts);

module.exports = router;