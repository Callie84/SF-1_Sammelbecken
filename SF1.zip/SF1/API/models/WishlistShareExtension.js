// Erweiterung für Share-Funktion
WishlistSchema.add({
  shareToken: String,
  shareExpires: Date
});