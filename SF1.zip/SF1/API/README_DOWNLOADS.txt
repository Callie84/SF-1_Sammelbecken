📥 Download-Zentrale:
- GET /downloads/html/:file → HTML-Dateien
- GET /downloads/pdf/:file → PDF-Dateien
- GET /downloads/csv/:file → CSV-Dateien
- Ablage: /public/downloads/(typ)/dateiname.ext