// späteres Mongoose Schema oder JSON Modell
module.exports = {
  strain: '',
  seedbank: '',
  price: 0.0
};