💰 Preisalarm – Teil 1:
- POST /price-alert → Preisalarm anlegen
- GET /price-alert → Alle eigenen Alarme anzeigen
- DELETE /price-alert/:id → Alarm löschen
- Modell: PriceAlert.js