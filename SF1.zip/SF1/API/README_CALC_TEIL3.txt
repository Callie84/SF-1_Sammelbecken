📊 Stromkosten/Ertragsrechner – Teil 3:
- Historische Daten:
  • GET /calc/history/power?sensorId=&start=&end=
  • GET /calc/history/yield/:cycleId
- Services: getPowerHistory(), getYieldHistory()
- Auth erforderlich