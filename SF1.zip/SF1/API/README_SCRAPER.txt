Starte den Cronjob mit `node cron/updatePrices.js`
Routen sind unter /api/scrape verfügbar.
package.json lädt alle nötigen Module mit `npm install`