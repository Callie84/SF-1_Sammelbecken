❤️ User Auth – Teil 3:
- /favorite (POST): Sorte zu Favoriten hinzufügen
- /favorites (GET): Alle Favoriten anzeigen
- /premium (GET): Premiumstatus anzeigen
- /delete (DELETE): Benutzerkonto löschen
- Modell: UserExtension.js (Erweiterung zu User-Daten)