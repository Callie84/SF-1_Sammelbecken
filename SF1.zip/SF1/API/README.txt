Starte mit: node server.js
Benötigt: MongoDB, Node.js, API-Key