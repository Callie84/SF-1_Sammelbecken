💡 Preisalarm – Teil 2:
- Script prüft alle 30 Min, ob Sorten unter Zielpreis gefallen sind
- Wird per Cronjob automatisiert
- Benachrichtigung aktuell: Konsole (Platzhalter)
- Wird später ersetzt durch E-Mail / Telegram / Webpush